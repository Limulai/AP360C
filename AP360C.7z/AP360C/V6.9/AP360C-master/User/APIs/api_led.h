#ifndef __API_LED_H__
#define __API_LED_H__

#include <stdint.h>

#define ENABLE_FLASH4USER 1
#define DISABLE_FLASH4USER 0
#define ENABLE_LIGHT 1
#define DISABLE_LIGHT 0
#define LIGHT_ON 1
#define LIGHT_OFF 0

/*LED ���ȵȼ�*/
#define BRIGHTNESS_MAX     30
#define BRIGHTNESS_HIGHEST (BRIGHTNESS_MAX / 10 * 4)
#define BRIGHTNESS_HIGH    (BRIGHTNESS_MAX / 10 * 3)
#define BRIGHTNESS_MID     (BRIGHTNESS_MAX / 10 * 2)
#define BRIGHTNESS_LOW     (BRIGHTNESS_MAX / 10 * 1)
#define BRIGHTNESS_DEFAULT (BRIGHTNESS_MAX / 10 * 4)

/* blink parameter  */
#define CYC_BRIGHTNESS_FLASH 15000  /* uint: us */
#define CYC_TIMER_BRIGHTNESS_FLASH (CYC_BRIGHTNESS_FLASH / BRIGHTNESS_MAX)

/* ���ⲿ�ӿں�����*/
#define LED_POWER 1
#define LED_BOOST 2
#define LED_HIGH 3
#define LED_MID 4
#define LED_LOW 5
#define LED_DRYING 6
#define LED_CLEAN 7
#define LED_ALL 8
#define ON 1
#define OFF 0
typedef enum ledColor{
	green = 1,
	blue,
	orange,
	red
} ledColor;
				/* adding the uppercase words */
#define GREEN  (ledColor)1
#define BLUE   (ledColor)2
#define ORANGE (ledColor)3
#define RED    (ledColor)4

typedef struct led led;
struct led {
	ledColor color;
	uint8_t state : 1;
	uint8_t enableFlash4User : 1;
	uint8_t reserved : 6;
};

typedef struct apLeds apLeds;
struct apLeds {
	led ledPower;
	led ledBoost;
	led ledHigh;
	led ledMid;
	led ledLow;
	led ledDrying;
	led ledClean;
	
	//uint8_t brightFlashPeriodNms;
	uint32_t userFlashPeriodNus;
	uint32_t userLightDurationNus;
	uint8_t brightness : 7;
	uint8_t light_enable :1;
};



void InitAllLeds(void);
uint8_t SetLedColor(uint8_t whichLed, ledColor color);
uint8_t SetLedState(uint8_t whichLed, uint8_t state);
uint8_t SetLedFlashEnable(uint8_t whichLed, uint8_t onoff);
uint8_t SetLightEnable (uint8_t onoff);
uint8_t GetLightEnable(void);
uint8_t SetBrightness(uint8_t brightness);
uint8_t GetBrightness(void);
uint8_t SetUserFlashPeriod(uint32_t userFlashPeriodNus);
uint8_t SetUserLightDuration(uint32_t userLightDurationNus);
void PowerOnSignal(void);
void LedsBrightnessAdj(void);
#endif

