#ifndef __GIZWITS_H
#define __GIZWITS_H




void userHandle(void);
void userInit(void);

#endif



