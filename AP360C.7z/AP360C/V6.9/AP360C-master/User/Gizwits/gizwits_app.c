

#include "gizwits_app.h"
#include "gizwits_protocol.h"
#include "app_ap36xx.h"
#include "hal_uart.h"




/** �û�����ǰ�豸״̬�ṹ��*/
dataPoint_t currentDataPoint;

/**
* �û����ݻ�ȡ

* �˴���Ҫ�û�ʵ�ֳ���д���ݵ�֮�����д��������ݵĲɼ�,�����ж���ɼ�Ƶ�ʺ�������ݹ����㷨
* @param none
* @return none
*/

void userHandle(void)
{
	    
    currentDataPoint.valueled_power = !leds_control.led_power;//Add Sensor Data Collection
    currentDataPoint.valueled_clean = !leds_control.led_clean;//Add Sensor Data Collection
    currentDataPoint.valueled_drying = !leds_control.led_drying;//Add Sensor Data Collection
    currentDataPoint.valueled_boost = !leds_control.led_boost;//Add Sensor Data Collection
    currentDataPoint.valueled_high = !leds_control.led_high;//Add Sensor Data Collection
    currentDataPoint.valueled_mid = !leds_control.led_mid;//Add Sensor Data Collection
    currentDataPoint.valueled_low = !leds_control.led_low;//Add Sensor Data Collection
		
	currentDataPoint.valuefan_speed = g_fan_mode;//Add Sensor Data Collection
	currentDataPoint.valuesensor_temperature = g_temperature;//Add Sensor Data Collection
	currentDataPoint.valuesensor_humidity = g_humidity;//Add Sensor Data Collection
	currentDataPoint.valuesensor_pm_25 = g_pm25;//Add Sensor Data Collection
	currentDataPoint.valuesensor_pm_10 = g_pm10;//Add Sensor Data Collection
	currentDataPoint.valuesensor_formaldehyde_mgm3 = g_ch2o;//Add Sensor Data Collection
	//currentDataPoint.valuesensor_formaldehyde_mgm3 = ;//Add Sensor Data Collection
	currentDataPoint.valuestatus = g_SystemStatus;//Add Sensor Data Collection
	currentDataPoint.valuemalfunction_code = g_malfunction.malfunction_code;//Add Sensor Data Collection
    currentDataPoint.valuealarm_pm25 = g_malfunction.alarm_pm25_overRange;//Add Sensor Data Collection
    currentDataPoint.valuealarm_ch2o = g_malfunction.alarm_ch2o_overRange;//Add Sensor Data Collection
	
    currentDataPoint.valuefilter_usage_duration = g_clean_time[1]*256+g_clean_time[0];//Add Sensor Data Collection
	
	//		currentDataPoint.valuesensor_tungsten_break = g_tungsten_break;//Add Sensor Data Collection
//    currentDataPoint.valuetest_alarm = g_alarm;//Add Sensor Data Collection
	/*    
    currentDataPoint.valuetest_malfunction = ;//Add Sensor Data Collection
    */
	
	
	
	
		    /*
    currentDataPoint.valueled_power = ;//Add Sensor Data Collection
    currentDataPoint.valueled_clean = ;//Add Sensor Data Collection
    currentDataPoint.valueled_drying = ;//Add Sensor Data Collection
    currentDataPoint.valueled_boost = ;//Add Sensor Data Collection
    currentDataPoint.valueled_high = ;//Add Sensor Data Collection
    currentDataPoint.valueled_mid = ;//Add Sensor Data Collection
    currentDataPoint.valueled_low = ;//Add Sensor Data Collection
    currentDataPoint.valuesensor_tungsten_break = ;//Add Sensor Data Collection
    currentDataPoint.valuestatus = ;//Add Sensor Data Collection
    currentDataPoint.valuefan_speed = ;//Add Sensor Data Collection
    currentDataPoint.valuesensor_formaldehyde_ppm = ;//Add Sensor Data Collection
    currentDataPoint.valuesensor_formaldehyde_mgm3 = ;//Add Sensor Data Collection
    currentDataPoint.valuesensor_humidity = ;//Add Sensor Data Collection
    currentDataPoint.valuesensor_pm_25 = ;//Add Sensor Data Collection
    currentDataPoint.valuesensor_pm_10 = ;//Add Sensor Data Collection
    currentDataPoint.valuesensor_temperature = ;//Add Sensor Data Collection
    currentDataPoint.valuemalfunction_code = ;//Add Sensor Data Collection
    currentDataPoint.valuevolt_alarm = ;//Add Sensor Data Collection
    currentDataPoint.valuevolt_tungsten_l = ;//Add Sensor Data Collection
    currentDataPoint.valuevolt_tungsten_r = ;//Add Sensor Data Collection
    currentDataPoint.valuetest_alarm = ;//Add Sensor Data Collection
    currentDataPoint.valuetest_malfunction = ;//Add Sensor Data Collection

    */
}

/**
* �û���ʼ������

* �ڸú��������������������ʼ���Լ��û�������ݵĳ�ʼ
* @param none
* @return none
* @note �����߿��ڴ˺����������µ�������ʼ��״̬��ʼ��
*/
void userInit(void)
{
    uartxInit();        //printf��ӡ���ڳ�ʼ��
    memset((uint8_t*)&currentDataPoint, 0, sizeof(dataPoint_t));
}

