#ifndef __BSP_ADC_H
#define	__BSP_ADC_H


#include "stm32f10x.h"




// ע�⣺����ADC�ɼ���IO����û�и��ã�����ɼ���ѹ����Ӱ��
/********************ADC1����ͨ�������ţ�����**************************/
#define    ADC_APBxClock_FUN             RCC_APB2PeriphClockCmd
#define    ADC_CLK                       RCC_APB2Periph_ADC1

#define    ADC_GPIO_APBxClock_FUN        RCC_APB2PeriphClockCmd
#define    ADC_GPIO_CLK                  RCC_APB2Periph_GPIOA  
#define    ADC_PORT                      GPIOA

// ת��ͨ������
#define    NOFCHANEL										 5

#define    PhotoDiode_PIN                      GPIO_Pin_4
#define    PhotoDiode_CHANNEL                  ADC_Channel_4

#define    HighVolt_REF_PIN                      GPIO_Pin_0
#define    HighVolt_REF_CHANNEL                  ADC_Channel_0

#define    HighVolt_ALARM_PIN                      GPIO_Pin_1
#define    HighVolt_ALARM_CHANNEL                  ADC_Channel_1

#define    Tungsten_A_PIN                      GPIO_Pin_6
#define    Tungsten_A_CHANNEL                  ADC_Channel_6

#define    Tungsten_B_PIN                      GPIO_Pin_7
#define    Tungsten_B_CHANNEL                 ADC_Channel_7



// ADC1 ��Ӧ DMA1ͨ��1��ADC3��ӦDMA2ͨ��5��ADC2û��DMA����
#define    ADC_x                         ADC1
#define    ADC_DMA_CHANNEL               DMA1_Channel1
#define    ADC_DMA_CLK                   RCC_AHBPeriph_DMA1

#define HighVolt_Ref_Subscript 0
#define HighVolt_Alarm_Subscript 1
#define PhotoDiode_Subscript 2
#define Tungsten_B_Subscript 3
#define Tungsten_A_Subscript 4
extern __IO uint16_t ADC_ConvertedValue[NOFCHANEL];
/**************************��������********************************/
void               ADCx_Init                               (void);


#endif /* __BSP_ADC_H */

