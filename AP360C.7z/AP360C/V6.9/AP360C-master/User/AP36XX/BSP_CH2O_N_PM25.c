#include "BSP_CH2O_N_PM25.h"
#include "BSP_UART.h"

const uint8_t command_get_CH2O[SIZE_COMMAND_CH2O] = {0xa5, 0x5a, 0x02, 0x80, 0xaa};
const uint8_t command_get_PM25[SIZE_COMMAND_PM25] = {0XAA, 0XB4, 0X04, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0XFF, 0XFF, 0X02, 0XAB};
const uint8_t command_DSL03_PowerOn[SIZE_COMMAND_DSL] = {0XAA, 0X01, 0X00, 0X00, 0X00, 0X00, 0X01, 0X66, 0XBB};
const uint8_t command_DSL03_Read[SIZE_COMMAND_DSL] = {0XAA, 0X02, 0X00, 0X00, 0X00, 0X00, 0X01, 0X67, 0XBB};
const uint8_t command_A4CG_DeviceOn[SIZE_COMMAND_A4CG] = {0X33, 0X3E, 0X00, 0X0C, 0XA1, 0X00, 0X00, 0X01, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X01, 0X1F};
const uint8_t command_A4CG_DeviceOff[SIZE_COMMAND_A4CG] = {0X33, 0X3E, 0X00, 0X0C, 0XA1, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X01, 0X1E};
const uint8_t command_A4CG_Read[SIZE_COMMAND_A4CG] = {0X33, 0X3E, 0X00, 0X0C, 0XA4, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X01, 0X21};
const uint8_t command_A4CG_PassiveMode[SIZE_COMMAND_A4CG] = {0X33, 0X3E, 0X00, 0X0C, 0XA2, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X01, 0X1F} ;
const uint8_t command_A4CG_TimmingMode[SIZE_COMMAND_A4CG] = {0X33, 0X3E, 0X00, 0X0C, 0XA2, 0X00, 0X00, 0X01, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X01, 0X20} ;
const uint8_t command_FS503_PassiveMode[SIZE_COMMAND_FS503] = {0XFF, 0X01, 0X78, 0X41, 0X00, 0X00, 0X00, 0X00, 0X46};
const uint8_t command_FS503_ActiveMode[SIZE_COMMAND_FS503] = {0XFF, 0X01, 0X78, 0X40, 0X00, 0X00, 0X00, 0X00, 0X47};
const uint8_t command_FS503_Read[SIZE_COMMAND_FS503] = {0XFF, 0X01, 0X86, 0X00, 0X00, 0X00, 0X00, 0X00, 0X79};
/*
		 ��ȩģ�����õ����ݳ�ʼ��
*/
#define CH2O_MG_DATA_LENGTH  5
#define CH2O_PPM_DATA_LENGTH  5
uint16_t CH2O_mg_array[CH2O_MG_DATA_LENGTH]={0,0,0,0,0};
uint16_t CH2O_ppm_array[CH2O_PPM_DATA_LENGTH]={0,0,0,0,0};	
SENSOR_DataHandle CH2O_MG_DataHandle = {CH2O_mg_array, 1000, 0, CH2O_MG_DATA_LENGTH, 0};
SENSOR_DataHandle CH2O_PPM_DataHandle = {CH2O_ppm_array, 1000, 0, CH2O_PPM_DATA_LENGTH, 0};

/*
		 PM2.5ģ�����õ����ݳ�ʼ��
*/
#define PM25_DATA_LENGTH  5
#define PM10_DATA_LENGTH  5
uint16_t PM25_array[PM25_DATA_LENGTH]={0,0,0,0,0};
uint16_t PM10_array[PM10_DATA_LENGTH]={0,0,0,0,0};	
SENSOR_DataHandle PM25_DataHandle = {PM25_array, 1, 0, PM25_DATA_LENGTH, 0};
SENSOR_DataHandle PM10_DataHandle = {PM10_array, 1, 0, PM10_DATA_LENGTH, 0};


	
/*
���ܣ���SENSOR_DataHandle�ṹ���е�UnsignedDecimal����д�����ݣ�����������ˣ���д������ݻḲ�����ϵ�����
����: SENSOR_DataHandle * sensor_data_handle ���������ݽṹ��ָ��
			UnsignedDecimal *data  ��д������ݵ�ָ��
note:
*/
void PushToSensorArray(SENSOR_DataHandle * sensor_data_handle, uint16_t data){
	*(sensor_data_handle->sensor_data_array + sensor_data_handle->sensor_array_index) = data;
	if(++sensor_data_handle->sensor_array_index >= sensor_data_handle->data_length){
		sensor_data_handle->sensor_array_index = 0;
		sensor_data_handle->array_full_flag = 1;
	}	
}

/*
���ܣ��򴮿ڷ���һ֡����
������USART_TypeDef *uart  ʹ�õĴ��ں�
			uint8_t *command_addess  ��������ָ��
			uint8_t command_length   ������ֽ���
*/
uint8_t SendCommand(USART_TypeDef *uart, uint8_t *command_addess, uint8_t command_length){
	uint8_t i;
	for(i=0; i<command_length ; i++){
		while(USART_GetFlagStatus(uart,USART_FLAG_TC)==RESET);
		Usart_SendByte( uart, *(command_addess + i) );	
	}
	return 1;
}



/*
@Description: FS00503 detect range is between 1-1.5 mg/m3 and only output the data(mg/m3).
*/
uint8_t Read_FS00503_FromFIFO(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo, float *ch2o_mg){
	uint16_t temp_ch2o_ug;
	uint8_t ug_high_position, ug_low_position;

	/* 1, whether the bytes are valid? */
	if(uart_rx_fifo->num_bytes == NUM_FS00503_RECIVED_DATA
			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first) == 0xff
			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 1) == 0x86){
		/* ring buff data processing. */
		if(uart_rx_fifo->i_first + 2 < FIFO_BUFFER_SIZE) ug_high_position = uart_rx_fifo->i_first + 2;
		else ug_high_position = uart_rx_fifo->i_first + 2 - FIFO_BUFFER_SIZE;
		if(uart_rx_fifo->i_first + 3 < FIFO_BUFFER_SIZE) ug_low_position = uart_rx_fifo->i_first + 3;
		else ug_low_position = uart_rx_fifo->i_first + 3 - FIFO_BUFFER_SIZE;	
//		if(uart_rx_fifo->i_first + 6 < FIFO_BUFFER_SIZE) ppb_high_position = uart_rx_fifo->i_first + 6;
//		else ppb_high_position = uart_rx_fifo->i_first + 6 - FIFO_BUFFER_SIZE;
//		if(uart_rx_fifo->i_first + 7 < FIFO_BUFFER_SIZE) ppb_low_position = uart_rx_fifo->i_first + 7;
//		else ppb_low_position = uart_rx_fifo->i_first + 7 - FIFO_BUFFER_SIZE;
		
		temp_ch2o_ug = (uint16_t)*(uart_rx_fifo->data_buf + ug_high_position) * 256 + *(uart_rx_fifo->data_buf + ug_low_position);
	/* 2, whether the data within the rang 1.5mg/m3(1500ug/m3)*/	
		if(temp_ch2o_ug <= 1500)
		{
	/* 3, pass the valid data*/		
			*ch2o_mg = (float)(temp_ch2o_ug)/1000;
			return TRUE;
		}		
		else return OVER_RANGE;
	}
	else return WRONG_DATA;
}

/*
@ description: 
	
*/
uint8_t Read_A4CG_FromFIFO(USART_TypeDef *huart, sw_fifo_typedef *uart_rx_fifo, float *pm25, float *pm10){
	uint16_t temp_pm25, temp_pm10;
	uint8_t pm25_high_position, pm25_low_position, pm10_high_position, pm10_low_position;
	
	/* 1, if the bytes are valid?*/
	if(uart_rx_fifo->num_bytes >= NUM_A4CG_RECIVED_DATA
			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first) == 0x32
			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 1) == 0x3D){
			
		if(uart_rx_fifo->i_first + 6 < FIFO_BUFFER_SIZE) pm25_high_position = uart_rx_fifo->i_first + 6;
		else pm25_high_position = uart_rx_fifo->i_first + 6 - FIFO_BUFFER_SIZE;
		if(uart_rx_fifo->i_first + 7 < FIFO_BUFFER_SIZE) pm25_low_position = uart_rx_fifo->i_first + 7;
		else pm25_low_position = uart_rx_fifo->i_first + 7 - FIFO_BUFFER_SIZE;	
		if(uart_rx_fifo->i_first + 8 < FIFO_BUFFER_SIZE) pm10_high_position = uart_rx_fifo->i_first + 8;
		else pm10_high_position = uart_rx_fifo->i_first + 8 - FIFO_BUFFER_SIZE;
		if(uart_rx_fifo->i_first + 9 < FIFO_BUFFER_SIZE) pm10_low_position = uart_rx_fifo->i_first + 9;
		else pm10_low_position = uart_rx_fifo->i_first + 9 - FIFO_BUFFER_SIZE;		
				
		temp_pm25 = (uint16_t)*(uart_rx_fifo->data_buf + pm25_high_position) * 256 + *(uart_rx_fifo->data_buf + pm25_low_position);							
		temp_pm10 = (uint16_t)*(uart_rx_fifo->data_buf + pm10_high_position) * 256 + *(uart_rx_fifo->data_buf + pm10_low_position);
	/* 2, if the data are within the range?*/
		if(temp_pm25 <= 6000) //������ֵ
		{
	/* 3, pass the data */
			*pm25=(float)temp_pm25;
			*pm10=(float)temp_pm10;
			return TRUE;
		}	
		else return OVER_RANGE;
	}
	else return WRONG_DATA;		
}


uint8_t Read_LB_FromFIFO(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo, uint16_t *ch2o_mg, uint16_t *ch2o_ppm){
	uint8_t returnvalue;
	uint16_t temp_ch2o_mg, temp_ch2o_ppm;

	//�ȴ���ȩģ��ط�һ֡����
	if(uart_rx_fifo->num_bytes == NUM_LB_RECIVED_DATA
			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first) == 0xa5
			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 1) == 0x5a
			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_last - 1) == 0xaa){
		temp_ch2o_mg = (uint16_t)*(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 4) * 256 + *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 5);
		temp_ch2o_ppm = (uint16_t)*(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 6) * 256 + *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 7);
		if(temp_ch2o_mg <= 100){//������ֵ
//			PushToSensorArray(&CH2O_MG_DataHandle, CH_mg); 
//			PushToSensorArray(&CH2O_PPM_DataHandle, CH_ppm);
			*ch2o_mg = temp_ch2o_mg;
			*ch2o_ppm = temp_ch2o_ppm;
			returnvalue = TRUE;
		}			
		else returnvalue = FALSE;
	}
	else returnvalue = FALSE;
	//���fifo�е�����
	while(uart_rx_fifo->fifo_not_empty_flag){
		uart_get_byte(huart, uart_rx_fifo);
	}
	
	return returnvalue;
}




























/*
���ܣ������������ȩģ�飬��ȡ��ط���һ֡���ݲ�����
������ USART_TypeDef *huart ����Ӧ���ȩģ�����ӵĴ��ں�
			 sw_fifo_typedef *uart_rx_fifo ����Ӧ�������ںŵ�fifo

����ֵ�� 
note:��ȩģ��ط����ݸ�ʽ��A5 5A 06 80 01 05 00 04 AA ,CH_mg=(01*256+05)/100 mg/m3 , CH_ppm=(00*256+04)/100 ppm
		 �ֱ���Ϊ  0.01mg    ���̣� 0 - 1.00mg/m3
*/
//void GetCH2O_V2(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo){
//	uint32_t i=0;
//	uint16_t CH_mg, CH_ppm;
//	//���ͻ�ȡ��ȩ����ָ��
//	SendCommand(UART_CH2O, (uint8_t *)&command_get_CH2O, SIZE_COMMAND_CH2O);
//	//�ȴ���ȩģ��ط�һ֡����
//	while(uart_rx_fifo->num_bytes < NUM_CH20_RECIVED_DATA && (i++ < 0xffff));//i����ʱ�˳����˴�iһ��С��0xffff
//	if(uart_rx_fifo->num_bytes == NUM_CH20_RECIVED_DATA
//			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first) == 0xa5
//			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 1) == 0x5a
//			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_last - 1) == 0xaa){
//		CH_mg = (uint16_t)*(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 4) * 256 + *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 5);
//		CH_ppm = (uint16_t)*(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 6) * 256 + *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 7);
//		if(CH_mg <= 100){//������ֵ
//			PushToSensorArray(&CH2O_MG_DataHandle, CH_mg); 
//			PushToSensorArray(&CH2O_PPM_DataHandle, CH_ppm);
//		}			
//	}
//	//���fifo�е�����
//	while(uart_rx_fifo->fifo_not_empty_flag){
//		uart_get_byte(huart, uart_rx_fifo);
//	}
//}

//void Read_FS00503(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo){
//	uint32_t i=0;
//	uint16_t CH_ug, CH_ppb;
//	uint8_t ug_high_position, ug_low_position, ppb_high_position, ppb_low_position;
//	//���fifo�е�����
//	while(uart_rx_fifo->fifo_not_empty_flag){
//		uart_get_byte(huart, uart_rx_fifo);
//	}
//	//���ͻ�ȡ��ȩ����ָ��
//	SendCommand(UART_CH2O, (uint8_t *)&command_FS503_Read, SIZE_COMMAND_FS503);
//	//�ȴ���ȩģ��ط�һ֡����
//	while(uart_rx_fifo->num_bytes < NUM_FS00503_RECIVED_DATA && (i++ < 0x400000));//i����ʱ�˳�,iͨ��С��0x400000
//	if(uart_rx_fifo->num_bytes == NUM_FS00503_RECIVED_DATA
//			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first) == 0xff
//			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 1) == 0x86){
//				
//		if(uart_rx_fifo->i_first + 2 < FIFO_BUFFER_SIZE) ug_high_position = uart_rx_fifo->i_first + 2;
//		else ug_high_position = uart_rx_fifo->i_first + 2 - FIFO_BUFFER_SIZE;
//		if(uart_rx_fifo->i_first + 3 < FIFO_BUFFER_SIZE) ug_low_position = uart_rx_fifo->i_first + 3;
//		else ug_low_position = uart_rx_fifo->i_first + 3 - FIFO_BUFFER_SIZE;	
//		if(uart_rx_fifo->i_first + 6 < FIFO_BUFFER_SIZE) ppb_high_position = uart_rx_fifo->i_first + 6;
//		else ppb_high_position = uart_rx_fifo->i_first + 6 - FIFO_BUFFER_SIZE;
//		if(uart_rx_fifo->i_first + 7 < FIFO_BUFFER_SIZE) ppb_low_position = uart_rx_fifo->i_first + 7;
//		else ppb_low_position = uart_rx_fifo->i_first + 7 - FIFO_BUFFER_SIZE;		
//		
//		CH_ug = (uint16_t)*(uart_rx_fifo->data_buf + ug_high_position) * 256 + *(uart_rx_fifo->data_buf + ug_low_position);
//		CH_ppb = (uint16_t)*(uart_rx_fifo->data_buf + ppb_high_position) * 256 + *(uart_rx_fifo->data_buf + ppb_low_position);
//		if(CH_ug <= 2000){//������ֵ
//			PushToSensorArray(&CH2O_MG_DataHandle, CH_ug); 
//			PushToSensorArray(&CH2O_PPM_DataHandle, CH_ppb);
//		}			
//	}
//	//���fifo�е�����
//	while(uart_rx_fifo->fifo_not_empty_flag){
//		uart_get_byte(huart, uart_rx_fifo);
//	}
//}

//void Read_A4CG(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo){
//	uint32_t i=0;
//	uint16_t pm25, pm10;
//	uint8_t pm25_high_position, pm25_low_position, pm10_high_position, pm10_low_position;
//	//���fifo�е�����
//	while(uart_rx_fifo->fifo_not_empty_flag){
//		uart_get_byte(huart, uart_rx_fifo);
//	}
//	//���ͻ�ȡ��ȩ����ָ��
//	SendCommand(UART_PM, (uint8_t *)&command_A4CG_Read, SIZE_COMMAND_A4CG);
//	//�ȴ���ȩģ��ط�һ֡����
//	while(uart_rx_fifo->num_bytes < NUM_A4CG_RECIVED_DATA && (i++ < 0xfffff));//i����ʱ�˳�,iһ��С��0x40000
//	if(uart_rx_fifo->num_bytes == NUM_A4CG_RECIVED_DATA
//			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first) == 0x32
//			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 1) == 0x3D){
//			
//		if(uart_rx_fifo->i_first + 6 < FIFO_BUFFER_SIZE) pm25_high_position = uart_rx_fifo->i_first + 6;
//		else pm25_high_position = uart_rx_fifo->i_first + 6 - FIFO_BUFFER_SIZE;
//		if(uart_rx_fifo->i_first + 7 < FIFO_BUFFER_SIZE) pm25_low_position = uart_rx_fifo->i_first + 7;
//		else pm25_low_position = uart_rx_fifo->i_first + 7 - FIFO_BUFFER_SIZE;	
//		if(uart_rx_fifo->i_first + 8 < FIFO_BUFFER_SIZE) pm10_high_position = uart_rx_fifo->i_first + 8;
//		else pm10_high_position = uart_rx_fifo->i_first + 8 - FIFO_BUFFER_SIZE;
//		if(uart_rx_fifo->i_first + 9 < FIFO_BUFFER_SIZE) pm10_low_position = uart_rx_fifo->i_first + 9;
//		else pm10_low_position = uart_rx_fifo->i_first + 9 - FIFO_BUFFER_SIZE;		
//				
//		pm25 = (uint16_t)*(uart_rx_fifo->data_buf + pm25_high_position) * 256 + *(uart_rx_fifo->data_buf + pm25_low_position);							
//		pm10 = (uint16_t)*(uart_rx_fifo->data_buf + pm10_high_position) * 256 + *(uart_rx_fifo->data_buf + pm10_low_position);
//							
//		if(pm25 <= 6000 && pm10 <= 6000){//������ֵ
//			PushToSensorArray(&PM25_DataHandle, pm25); 
//			PushToSensorArray(&PM10_DataHandle, pm10);
//		}			
//	}
//	//���fifo�е�����
//	while(uart_rx_fifo->fifo_not_empty_flag){
//		uart_get_byte(huart, uart_rx_fifo);
//	}
//}

/*
���ܣ����������PM2.5ģ�飬��ȡ��ط���һ֡���ݲ�����
������ USART_TypeDef *huart ����Ӧ���ȩģ�����ӵĴ��ں�
			 sw_fifo_typedef *uart_rx_fifo ����Ӧ�������ںŵ�fifo

����ֵ�� 

note:��ȩģ��ط����ݸ�ʽ��AA C0 71 01 CA 01 B9 93 89 AB ,pm25=(0x01*256+0x71)/100 ug/m3 , pm10=(0x01*256+0xCA)/100 ug/m3
		 �ֱ���Ϊ  0.01mg    ���̣� PM2.5  0.0 - 999.9 ug/m3 ; PM10  0.0 - 1999.9 ug/m3 ;
*/
//void GetPM25_V2(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo){
//	uint32_t i=0;
//	uint16_t pm25, pm10;
//	//���ͻ�ȡ��ȩ����ָ��
//	SendCommand(UART_PM, (uint8_t *)&command_get_PM25, SIZE_COMMAND_PM25);
//	//�ȴ���ȩģ��ط�һ֡����
//	while(uart_rx_fifo->num_bytes < NUM_PM25_RECIVED_DATA && (i++ < 0xfffff));//i����ʱ�˳����˴�iһ��С��0xfffff
//	if(uart_rx_fifo->num_bytes == NUM_PM25_RECIVED_DATA
//			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first) == 0xaa
//			&& *(uart_rx_fifo->data_buf + uart_rx_fifo->i_last - 1) == 0xab){
//		pm25 = (uint16_t)*(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 3) * 256 + *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 2);
//		pm10 = (uint16_t)*(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 5) * 256 + *(uart_rx_fifo->data_buf + uart_rx_fifo->i_first + 4);
//		if(pm25 <= 9999 && pm10 <= 19999){//������ֵ
//			PushToSensorArray(&PM25_DataHandle, pm25); 
//			PushToSensorArray(&PM10_DataHandle, pm10);
//		}			
//	}
//	//���fifo�е�����
//	while(uart_rx_fifo->fifo_not_empty_flag){
//		uart_get_byte(huart, uart_rx_fifo);
//	}
//}


//void PrintCH2O(void){
//	uint16_t CH_mg = 0, CH_ppm = 0;
//	GetCH2O(UART_CH2O, &CH2O_RX_FIFO, &CH_mg, &CH_ppm);
//	
//	float f_mg = (float)CH_mg/100;
//	float f_ppm = (float)CH_ppm/100;
//	printf("CH2O: ");
//	printf("%3g",f_mg );
//	printf("  mg/m3\r\n");
//	printf("      ");
//	printf("%3g",f_ppm );
//	printf("  ppm\r\n\r\n");
//}


//void PrintPM(void){
//	uint16_t PM_10 = 0, PM_2_5 = 0;
//	GetPM(UART_PM, &PM_RX_FIFO, &PM_2_5, &PM_10);
//	
//	float f_PM_2_5 = (float)PM_2_5/10;
//	float f_PM_10 = (float)PM_10/10;
//	printf("PM2.5 : ");
//	printf("%4g",f_PM_2_5 );
//	printf(" ug/m3\r\n");
//	printf("PM10  : ");
//	printf("%4g",f_PM_10 );
//	printf(" ug/m3\r\n\r\n");
//}








