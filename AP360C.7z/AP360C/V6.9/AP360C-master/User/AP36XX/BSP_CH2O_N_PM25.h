#ifndef __BSP_CH2O_N_PM25_H
#define	__BSP_CH2O_N_PM25_H

#include "stm32f10x.h"
#include "sw_fifo.h"


#define TRUE 1
#define FALSE 0
#define WRONG_DATA 2
#define OVER_RANGE 3
/*
		��������ģ���Ӧ�Ĵ��ںš�FIFO���Լ�������������
*/
#define UART_CH2O USART3
#define UART_PM  USART3
#define CH2O_RX_FIFO uart3_rx_fifo
#define PM_RX_FIFO uart3_rx_fifo

#define LENGTH_CH2O_DATA 5

#define SIZE_COMMAND_CH2O 5
#define SIZE_COMMAND_PM25 19
#define SIZE_COMMAND_DSL 9
#define SIZE_COMMAND_A4CG 16
#define SIZE_COMMAND_FS503 9
#define NUM_LB_RECIVED_DATA  9
#define NUM_PM25_RECIVED_DATA  10
#define NUM_FS00503_RECIVED_DATA 9
#define NUM_A4CG_RECIVED_DATA 32

extern const uint8_t command_get_CH2O[SIZE_COMMAND_CH2O];
extern const uint8_t command_get_PM25[SIZE_COMMAND_PM25];
extern const uint8_t command_DSL03_PowerOn[SIZE_COMMAND_DSL];
extern const uint8_t command_DSL03_Read[SIZE_COMMAND_DSL] ;
extern const uint8_t command_A4CG_DeviceOn[SIZE_COMMAND_A4CG] ;
extern const uint8_t command_A4CG_DeviceOff[SIZE_COMMAND_A4CG] ;
extern const uint8_t command_A4CG_Read[SIZE_COMMAND_A4CG] ;
extern const uint8_t command_A4CG_PassiveMode[SIZE_COMMAND_A4CG] ;
extern const uint8_t command_A4CG_TimmingMode[SIZE_COMMAND_A4CG] ;
extern const uint8_t command_FS503_PassiveMode[SIZE_COMMAND_FS503] ;
extern const uint8_t command_FS503_ActiveMode[SIZE_COMMAND_FS503] ;
extern const uint8_t command_FS503_Read[SIZE_COMMAND_FS503] ;

/*
  С���ṹ�壬��value/divisor �ɵõ�С��ֵ
*/
typedef struct{
	uint16_t value;
	uint8_t divisor;
}UnsignedDecimal;

typedef struct{
	uint16_t *sensor_data_array;
	uint16_t divisor;
	uint8_t sensor_array_index;  // ָ���������������ݵ���һ��
	uint8_t data_length;
	uint8_t array_full_flag;
	
}SENSOR_DataHandle;

extern SENSOR_DataHandle CH2O_MG_DataHandle;
extern SENSOR_DataHandle CH2O_PPM_DataHandle;
extern SENSOR_DataHandle PM25_DataHandle;
extern SENSOR_DataHandle PM10_DataHandle;

uint8_t SendCommand(USART_TypeDef *uart, uint8_t *command_addess, uint8_t command_length);
void PushToSensorArray(SENSOR_DataHandle * sensor_data_handle, uint16_t data);
//void GetCH2O_V2(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo);
//void GetPM25_V2(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo);
uint8_t Read_FS00503_FromFIFO(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo, float *ch2o_mg);
uint8_t Read_A4CG_FromFIFO(USART_TypeDef *huart, sw_fifo_typedef *uart_rx_fifo, float *pm25, float *pm10);
#endif /* __UART_H */


