/*
@   2017-5-31  Synchronize to AP360S_FreeRTOS_V2.3
			 1, Add command for on/off power of pm module .
	
	2017-6-3  Add AI task.
	2017-6-5  Synchronize to AP360S_FreeRTOS_V2.5
	2017-6-6  Synchronize to AP360S_FreeRTOS_V2.6
	2017-6-12  Synchronize to AP360S_FreeRTOS_V3.1
	
	2017-6-13  AP360C_FreeRTOS_V4.1
	1, after reduce number of tasks, system stable.
	
	2017-6-21  AP360C_FreeRTOS_V4.11
	1, modify humidity to 99%
	
	2017-6-22  AP360C_FreeRTOS_V4.2
	1, add lock function.
	2, add malfunction_code.
	
	2017-6-22  AP360C_FreeRTOS_V4.3
	1��modify humidity from 99% to 97%
	2, add fan_speed_ctr in cloud for control fan 
	3, add SetFan command for using uart to control fan
	
	AP360C_FreeRTOS_V4.4
	2017-6-29  
	1, modiry the read and write wyas of the data in eeprom
	2, improve the task_pair function.
	2017-6-30
	3, add the function to show software version while machine power on.
	2017-7-4
	4, change the promote command to on/off the machine.
	5, modify max humidity value from 97% to 99%.
	6, add the function to detect the disconnection of modules(pm2.5, humidity, ch2o);
	7, change the binding time from 0 to 10.
	
	AP360C_FreeRTOS_V4.5
	2017-7-6
	1, fix the led_power interfere the power on signal.
	2, add two data point to show pm2.5&cho2 over range.
	2017-7-26
	3, when system_state == poweroff, do not detect pm2.5 & ch2o.
	4, improve pair mode remind signal.
	5, improve the pm2.5 function.
	6, resume to using a task to adjust the brightness.
	7, change the 15s power button press to 5s
	8, change the PWM of fan driver to adapt the new transformer.
	9, change the implemention of shut down pm2.5 module when system poweroff.
	
	AP360C_FreeRTOS_V4.6
	2017-8-14
	1, change the high_volt stable duration from 1s to 2s
	2, delete the tungsten detect function.
	3, modify the implement of key detection.
	
	AP360C_FreeRTOS_V4.7
	2017-8-22
	1, fixed the issue of unexpected action that can ajuste fan_mode while poweroff. 
	2, modify the implement of pm2.5 function.
	
	AP360C_FreeRTOS_V4.8
	2017-8-28
	1, modify the alarm detection, set the low limit from 1.8 to 1.0 when system in fan_stop_mode.
	2, modify the 14KV_REF_PWM from 86 to 83
	3, modified the gizwits protocol to adapt the new datapoints
	4, delete the function that into drying mode when humidity too high.
	5, after power on, into ai mode automatically.
	6, after turbo counting end, into ai mode automatically.
	7, after power on, first pressing mode button will make the fan switching to mid mode. 
	
	AP360C_FreeRTOS_V4.9
	1, make the time of poweron signal advanced. 
	2, modified the function of SetFanMode.
	3, supplement the setting of enabling the g_ligh_enable.
	4, modified the function of pm2.5.
	5, modified the function of ch2o.
	6, modified the adjustment of led brightness.
	7, changed the ch2o CH2O_ALARM_MAX from 0.1 to 0.15.
	8, add a soft_timer to count the sleep duration, turn on all leds till 6hour after the sleep action.
	
	AP360C_FreeRTOS_V4.10
	2017-9-19
	1, update the pm task.
	2, delete the ch20 warn.
	3, change the ch2o operation condition.
	
	AP360C_FreeRTOS_V5.1
	2017-9-27
	1, update the gizwits protocol files
	2, adding g_no_ch2o_module for identify the product.
	
	AP360C_FreeRTOS_V5.2
	1, changed the clean mode disp;
	2, changed the AI mode disp(led power become blue);
	3, add the disp of PM (led boost can be green, orange, red);
	4, add the api_led module;
	5, changed the adjust fan function;
	6, changed the led_power flash frequence;
	
	AP360C_FreeRTOS_V5.2.2
	1, add the red_led blue_led disp in the function of showing software version.

	AP360C_FreeRTOS_V5.3
	2017-11-25
	1,  change the positon of disp_sw hehind the power_on_signal
	2,  change the poweron signal direction form left to right
	3,  after display sw, it turn to mode_mormal
	4,  set clean_time bigger than max_clean_time when check the SW
	5,  modified the watchdogFeed from TaskScanKeys to TaskChangeSystemOutput
	6,  make the fan control function synchronization with ap360s
	7,  modified the TaskCountCleanTime
	
	AP360C_FreeRTOS_V5.3.2
	2017-11-28
	1,  modified the TaskCountCleanTime, make it same as ap360s
	
	AP360C_FreeRTOS_V5.3.3
	2017-11-30
	1, fix the bug that when clean mode, it can change the pm indicator.
	2, whenever it can clear the clean time, not only the clean mode.
	
	AP360C_FreeRTOS_V5.4
	2017-12-2
	1, fix the bug that when clean mode, it can detect the network condition.
	2, fix the bug that when plug socket, clean time will plus 1.
	3, comment the task detecting the ch2o module.
	4, added a condition that makes AI_func works when machine in the clean mode.
	
	AP360C_FreeRTOS_V5.5
	2017-12-2
	1, fixed the timming function;
	2, fixed the pm2.5 module issue that will automatically work after plug in.
	3, 
	
	AP360C_FreeRTOS_V5.5.2
	2017-12-4
	1, changed  VOLT_PWM_AI from  REF_PWM_14KV  to  REF_PWM_16KV5 
	
	AP360C_FreeRTOS_V5.5.3
	2017-12-6
	1, fixed the bug that clean time still counting when poweroff	
	
	AP360C_FreeRTOS_V5.6
	2017-12-14
	1, make buzzer silent when ap into cleanning mode.
	2, initialize the watchdog befor other peripherals.
	
	AP360C_FreeRTOS_V6.0
	2018-6-25
	1, adjust the pm2.5 data fetch&handle module, passing mode and PM2.5 runnig while power on state 
	2, delete error output (through printf()) in pm2.5 and 1080 module.
	
	AP360C_FreeRTOS_V6.1
	2018-7-2
	1, change the firmware display implement.
	2, change lot of global veriable to volatile.
	
	
	version 6.4
	1, anytime the hardfault occur, it will reset mcu and set system_status to MODE_NORMAL after restart.
	2, and critical protection to read and write action of eeprom, H&T sensor and pm25 module.
	3, add ramdon value write protection in eeprom. Ramdon value(clean time) written in eeprom can be detected and 
	it will write the last clean time value to the eeprom to fix the wrong value that has been written in eeprom.
	The clean time value written in eeprom should be incremented by one each time.
	4, switch the optimization of compiler to level 3(highest)
	5, add iwatch dog acc written in eeprom and can be review through cli.
	
	version 6.8		Author:LSM		Time:2019-01-23
	1. change CLEAN_TIME_MAX_DEFAULT to 2016 ,extending the wait_time_to_clean from 2 weeks to 3 months.

*/


#include "stm32f10x.h"
#include <stdio.h>
#include "serial.h"
#include "BSP_AP360_GPIO.H"
#include "BSP_TIMER.h" 
#include "BSP_EEPROM.h"	
#include "BSP_SysTick.h"
#include "BSP_RCC.h"
#include "BSP_UART.h"
//#include "BSP_HDC1080.h"
#include "BSP_ADC.h"
#include "BSP_CH2O_N_PM25.h"
#include "sw_iic.h"
#include "sw_fifo.h"
#include "filter.h"
#include "app_ap36xx.h"
#include "cli_zhu.h"
#include "UARTprintf.h"
#include "api_led.h"
#include "api_fan.h"

#include "FreeRTOS.h"
#include "task.h"
#include "event_groups.h"
#include "semphr.h"

#include "hal_uart.h"
#include "gizwits_product.h"
#include "gizwits_protocol.h"

/* THE software version */
const uint8_t software_version[2] = {7, 2};
extern TimerHandle_t sleep_tm;
TimerHandle_t high_volt_stable_tm;  //declare a timer_handler for high volt delay detect. 

void PowerOnSignal(void);
void ResumeData(void);
void vApplicationIdleHook(void);
void disp_swv(void);

extern void TimerHighVoltStable(TimerHandle_t pxTimer);


//#define SECURITY_DETECT 1
//extern SemaphoreHandle_t  xSemphrUart3;
extern dataPoint_t currentDataPoint;

void delay_ms(unsigned int ms){
	unsigned i=0;
	while(ms--){
		i=8000;
		while(i--);
	}
}

typedef struct{
	FlagStatus PORRST:1;
	FlagStatus PINRST:1;
	FlagStatus SFTRST:1;
	FlagStatus IWDGRST:1;
	FlagStatus WWDGRST:1;
	FlagStatus LPWRRST:1;
	uint8_t reseved:2;
	
}reset_flags_t;

static reset_flags_t reset_flags;
reset_flags_t GetResetFlags(){
	
	reset_flags.PORRST =  RCC_GetFlagStatus(RCC_FLAG_PORRST);
	reset_flags.PINRST = RCC_GetFlagStatus(RCC_FLAG_PINRST);
	reset_flags.SFTRST = RCC_GetFlagStatus(RCC_FLAG_SFTRST);
	reset_flags.IWDGRST = RCC_GetFlagStatus(RCC_FLAG_IWDGRST);
	reset_flags.WWDGRST = RCC_GetFlagStatus(RCC_FLAG_WWDGRST);
	reset_flags.LPWRRST = RCC_GetFlagStatus(RCC_FLAG_LPWRRST);
	reset_flags.reseved = 0;
	
	return reset_flags;
}

void HandleResetFlags(void){
	if (reset_flags.PORRST) {
		UARTprintf("RCC_FLAG_PORRST.\r\n");
	}
	if (reset_flags.PINRST){
		UARTprintf("RCC_FLAG_PINRST.\r\n");
	}
	if (reset_flags.SFTRST){
		UARTprintf("RCC_FLAG_SFTRST.\r\n");
	}
	if (reset_flags.IWDGRST){
		g_SystemStatus = MODE_NORMAL;
		AccIWDG();
		UARTprintf("RCC_FLAG_IWDGRST.\r\n");
		
	}
	if (reset_flags.WWDGRST){
		UARTprintf("RCC_FLAG_WWDGRST.\r\n");
	}
	if (reset_flags.LPWRRST){
		UARTprintf("RCC_FLAG_LPWRRST.\r\n");
	}
	
	RCC_ClearFlag();
}


//#define TEST_HARDFAULT_BEFORE_RTOS_STATR
int main(void)
{
//	uint8_t i;
			/* 1, MCU initialization*/
	//HSE_SetSysClock(RCC_PLLMul_9);
	//SysTick_Init();	
	__disable_irq();
	
	reset_flags = GetResetFlags();
	

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
			/* 4, watch dog. */
	#ifdef WATCH_DOG
	watchdogInit(5); /* watch dog ����10�� */
	#endif
	
	uartxInit();        //print serial port init
	
	GpioInit();
	ADVANCE_TIM_Init();//TIM1
	GENERAL_TIM_Init();//TIM4  PWM���
	TIM2_Init();	
	I2C_EE_Init();
	SW_I2C_Config();
	ADCx_Init();
	USART_Config(); //uart3 initialization	
	
	InitAllLeds();
	InitFan();
	
	
			/* 2, peripheral device initialization */
	delay_ms(500);
	/* delay 500 ms for hdc1080 warm up. */
	InitHDC1080_sw_iic();
//	g_fan_mode = BOOST;//When poweron, into ai mode
			/* gizwits initialization */
	gizwitsInit();
	userInit();  //dataPoint_t memory allocate
	timerInit(); //timer3 initialization for gizwits_protocol
  uartInit(); //UART2 initialization for wifi module
			/* 3, data resume, get these settable parameter from eeprom */
	ResumeData();

	
			/* poweron signal */
//	PowerOnSignal();
	UARTprintf("system started.\r\n");
	HandleResetFlags();
			/* show the version of the software */
	disp_swv();
	
	g_SystemStatus = MODE_NORMAL;//�ϵ簴������

/* 5, anything about free rtos */
	/* ���������ź��� , for communicate with ch2o module and pm2.5 module. These modules are use the same communicate port, uart3. */
//	xSemphrUart3 = xSemaphoreCreateMutex();
	//sleep_tm = xTimerCreate("timer", configTICK_RATE_HZ*3600*6, pdFALSE, (void *)i, TimerSleepCounter );	
	
	xTaskCreate(vTaskCmdAnalyze, "cli_zhu", 256, NULL, 1, &xCmdAnalyzeHandle);
	xTaskCreate(TaskChangeSystemOutput, "stauts change", 256, NULL, 3, NULL);
	xTaskCreate(TaskGizwits, "Gizwits", 128, NULL, 1, NULL);
	
	xTaskCreate(TaskSecurity, "security", 128, NULL, 1, NULL);
	xTaskCreate(TaskScanKeys, "key_scan", 128, NULL, 4, NULL);
	xTaskCreate(TaskGetVoltDiodeAndAdj, "Detect diode", 40, NULL, 1, NULL);
	xTaskCreate(TaskGetPM, "PM2.5", 80, NULL, 1, NULL);
	xTaskCreate(TaskHumidity, "humidity", 40, NULL, 1, NULL);
	xTaskCreate(TaskCountCleanTime, "clean time", 40, NULL, 1, NULL);
	xTaskCreate(TaskDetectNetwork, "D Network", 64, NULL, 1, NULL);
	
	high_volt_stable_tm = xTimerCreate("timer", configTICK_RATE_HZ*2, pdFALSE, (void *)1, TimerHighVoltStable );	
	
				/* simulate hard fault occur before rtos start */
	#ifdef TEST_HARDFAULT_BEFORE_RTOS_STATR
	if (g_SystemStatus == MODE_POWEROFF) {
		uint8_t * pt;
		pt = (uint8_t *)0x0000033;
		*pt = 5;
	}
		
	#endif
	
	vTaskStartScheduler();
	while(1){
//		Usart_SendBytes( USART1, "12345678900987654321\r\n", 20);
		//UARTprintf("1234567890abcd%d%d\r\n", 5, 5);
	}	
}

void vApplicationIdleHook(void){
//	userHandle();      
//	gizwitsHandle((dataPoint_t *)&currentDataPoint);
//	GetLightDiode();
}




void ResumeData(void){
	uint8_t temp_array[2];
					/* make sure that read action will be sucess. */
	for (unsigned char i = 0; i<10; i++) {		
		if(I2C_EE_BufferRead((uint8_t *)(g_clean_time), CLEAN_TIME_ADDR, 2) == 1){
			break;
		}
	}
	//I2C_EE_BufferRead((uint8_t *)(g_clean_time), CLEAN_TIME_ADDR, 2);
	I2C_EE_BufferRead(temp_array, CLEAN_TIME_MAX_ADDR, 2);
	g_clean_time_max = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	I2C_EE_BufferRead(temp_array, CLEAN_TIME_RESOLUTION_ADDR, 2);
	g_clean_time_resolution = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	I2C_EE_BufferRead(temp_array, BOOST_TIME_MAX_ADDR, 2);
	g_boost_time_max = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	I2C_EE_BufferRead(temp_array, BOOST_TIME_RESOLUTION_ADDR, 2);
	g_boost_time_resolution = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	I2C_EE_BufferRead(temp_array, DRYING_TIME_MAX_ADDR, 2);
	g_drying_time_max = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	I2C_EE_BufferRead(temp_array, DRYING_TIME_RESOLUTION_ADDR, 2);
	g_drying_time_resolution = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	
	I2C_EE_BufferRead((uint8_t *)(&g_ala_enable), ALA_ENABLE_ADDR, 1);
	I2C_EE_BufferRead((uint8_t *)(&g_tun_enable), TUN_ENABLE_ADDR, 1);
	
	// check if hardware fault happend last time
	if (GetHardFaultFlag() == 1) {
		ClearHardFaultFlag();
		ResumeCriticalData();
	}
}

/*
	using led to show the software version
	
*/
void disp_swv(void){
	uint8_t version;
	uint8_t subversion;
	uint8_t i;
	version = software_version[0];
	subversion = software_version[1];
	
	if (0==key_state(key_mode_GPIO_Port, key_mode_Pin)){
		delay_ms(20);
		if (0==key_state(key_mode_GPIO_Port, key_mode_Pin)){
			LED_POWER_BLUE();
			LED_BOOST_RED();		
		}
		while(0==key_state(key_mode_GPIO_Port, key_mode_Pin)){
			#ifdef WATCH_DOG
			watchdogFeed();	
			#endif	
			delay_ms(20);
		};
		for (i=0; i<version; i++){
			//SetLedState(LED_CLEAN, LIGHT_ON);
			LED_CLEAN_GREEN();
			delay_ms(100);
			//SetLedState(LED_CLEAN, LIGHT_OFF);
			LED_CLEAN_OFF();
			delay_ms(500);
			#ifdef WATCH_DOG
			watchdogFeed();	
			#endif
		}
		
		LED_BOOST_ORANGE();
		
		for (i=0; i<subversion; i++){
			//SetLedState(LED_LOW, LIGHT_ON);
			LED_LOW_GREEN();
			delay_ms(100);
			//SetLedState(LED_LOW, LIGHT_OFF);
			LED_LOW_OFF();
			delay_ms(500);
			#ifdef WATCH_DOG
			watchdogFeed();	
			#endif
		}	
		
						/* �޸����ʱ��  */
		g_clean_time[CLEAN_TIME_HIGH] = (CLEAN_TIME_MAX_DEFAULT + 1) / 256;
		g_clean_time[CLEAN_TIME_LOW] = (CLEAN_TIME_MAX_DEFAULT + 1) % 256;
		I2C_EE_BufferWrite((uint8_t *)(g_clean_time), CLEAN_TIME_ADDR, 2);
		
		g_SystemStatus = MODE_NORMAL;
	
	}  // end if
}

